<h1 align="center">FckSpotify</h1>

<div align="center">
	<a href="https://t.me/ItsMeAsada">
        <img src="https://img.shields.io/badge/Chat-Telegram-blue" alt="telegram">
    </a>
    <a href="https://github.com/Asadaaaaa">
        <img src="https://img.shields.io/badge/Profile-Github-lightgrey" alt="pfgh">
    </a>
</div>
    <br><br>
    ✔️ For Windows Desktop only. (Microsoft store version is not suitable)
    <br>
    ✔️ Blocks all banner, video and audio ads in the client
    <br>
    ✔️ Unlocks the skip function of any track
    <br>
    ✔️ Full screen mode activated
    <br>
    ✔️ Podcasts disabled (optional)
    <br>
    ✔️ Blocks automatic updates (optional)
    <br>
    ✔️ Automatic cache clearing (optional)
    <br>
    ✔️ Activated "Made For You" in the left sidebar
    <br>
    ✔️ Disabled Sentry (Prevented Sentry from sending console log/error/warning to Spotify developers)
    <br>
    ✔️ Disabled logging (Stopped various elements to log user interaction)
    <br>
    ✔️ Removed RTL rules (Removed all right-to-left CSS rules to simplify CSS files)
    <br>

<div align="center">
	<h2>How to setup?</h2>
</div>

 - <h3>Step Installation:</h3>
 1. Just download and run [Install.bat](https://github.com/Asadaaaaa/FckSpotify/releases/download/1.0/Install.bat)
 - <h3>Step Uninstallation:</h3>
 1. Just download and run [Uninstall.bat](https://github.com/Asadaaaaa/FckSpotify/releases/download/1.0/Uninstall.bat)




<div align="center">
	<h2>Additional Notes:</h2>
</div>

* FckSpotify will only work correctly on the latest versions of Spotify, please make sure of this before asking a question.  
* The modifiable files are replaced by the Spotify installer every time it is updated, so you will need to apply the patch again when this happens.
* FckSpotify will be installed even if you are using Spicetify, but you may need to run Install.bat again after running the `spicetify apply` or other commands.
