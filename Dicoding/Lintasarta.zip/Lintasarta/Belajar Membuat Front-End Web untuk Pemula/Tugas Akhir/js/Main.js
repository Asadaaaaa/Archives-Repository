import EventsHandler from "./events/EventsHandler.js";

class Main {
  constructor() {
    this.localeStorageKey = 'BOOK_KEY'
    this.renderEvent = 'render-book'
    this.bookData = [];
    this.init();
  }

  init() {
    new EventsHandler(this);
  }

  checkForStorage() {
    return typeof (Storage) !== 'undefined';
  }

  findBook(bookID) {
    for (const bookItem of this.bookData) {
      if (bookItem.id === bookID) {
        return bookItem;
      }
    }
    return null;
  }

  putBookList(bookObject) {
    if (this.checkForStorage()) {
      if (localStorage.getItem(this.localeStorageKey) !== null) {
        this.bookData = JSON.parse(localStorage.getItem(this.localeStorageKey));
      }

      this.bookData.unshift(bookObject);
      localStorage.setItem(this.localeStorageKey, JSON.stringify(this.bookData));
    }
  }

  finishRead(bookID) {
    const bookTarget = this.findBook(bookID);
    if (bookTarget == null) return;

    bookTarget.isRead = true;
    localStorage.setItem(this.localeStorageKey, JSON.stringify(this.bookData));
    document.dispatchEvent(new Event(this.renderEvent));
  }

  unfinishRead(bookID) {
    const bookTarget = this.findBook(bookID);
    if (bookTarget == null) return;
    bookTarget.isRead = false;
    localStorage.setItem(this.localeStorageKey, JSON.stringify(this.bookData));
    document.dispatchEvent(new Event(this.renderEvent));
  }

  clearBook(bookID) {
    if (!confirm('apa anda yakin ingin menghapus data ini?')) {
      document.dispatchEvent(new Event(this.renderEvent));
    } else {
      const bookTarget = this.findBook(bookID);
      if (bookTarget === -1) return;

      this.bookData.splice(bookTarget, 1);
      localStorage.setItem(this.localeStorageKey, JSON.stringify(this.bookData));

      document.dispatchEvent(new Event(this.renderEvent));
    }
  }

  renderBookList(bookObject) {
    const bookTitle = document.createElement('h3');
    bookTitle.innerText = bookObject.title;

    const bookAuthor = document.createElement('p');
    bookAuthor.innerText = `Penulis: ${bookObject.author}`;

    const bookYear = document.createElement('p');
    bookYear.innerText = `Tahun: ${bookObject.year}`;


    const articleContainer = document.createElement('article');
    articleContainer.classList.add('book_item')
    articleContainer.append(bookTitle, bookAuthor, bookYear);

    const actionContainer = document.createElement('div');
    actionContainer.classList.add('action');

    if (!bookObject.isRead) {
      const greenBtn = document.createElement('button');
      greenBtn.classList.add('green');
      greenBtn.innerText = `Selesai dibaca`;

      const redBtn = document.createElement('button');
      redBtn.classList.add('red');
      redBtn.innerText = `Hapus buku`;

      greenBtn.addEventListener('click', () => {
        this.finishRead(bookObject.id);
      })

      redBtn.addEventListener('click', () => {
        this.clearBook(bookObject.id);
      })
      actionContainer.append(greenBtn, redBtn);
    } else {
      const greenBtn = document.createElement('button');
      greenBtn.classList.add('green');
      greenBtn.innerText = `Belum selesai dibaca`;

      greenBtn.addEventListener('click', () => {
        this.unfinishRead(bookObject.id);
      })

      const redBtn = document.createElement('button');
      redBtn.classList.add('red');
      redBtn.innerText = `Hapus buku`;

      redBtn.addEventListener('click', () => {
        this.clearBook(bookObject.id);
      })
      actionContainer.append(greenBtn, redBtn);
    }
    articleContainer.append(actionContainer);
    return articleContainer;
  }

  addBook(){
    const bookId = new Date()
    const bookTitle = document.getElementById('inputBookTitle').value;
    const bookAuthor = document.getElementById('inputBookAuthor').value;
    const bookYear = document.getElementById('inputBookYear').value;
    const bookIsRead = document.getElementById('inputBookIsComplete').checked;
    const newBook = {
      id: bookId,
      title: bookTitle,
      author: bookAuthor,
      year: bookYear,
      isRead: bookIsRead
    }
    this.putBookList(newBook);
    document.dispatchEvent(new Event(this.renderEvent));
  }
};

new Main();