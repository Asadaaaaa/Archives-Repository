class OnRenderBook {
  constructor(Main) {
    document.addEventListener(Main.renderEvent, () => {
      const uncompletedReadBookList = document.getElementById('incompleteBookshelfList');
      uncompletedReadBookList.innerHTML = '';
  
      const completedReadBookList = document.getElementById('completeBookshelfList');
      completedReadBookList.innerHTML = '';
      
      for(const bookItem of Main.bookData){
          const bookElement = Main.renderBookList(bookItem);
          if(bookItem.isRead){
              completedReadBookList.append(bookElement);
          }else{
              uncompletedReadBookList.append(bookElement);
          }
      }
  })
  }
}

export default OnRenderBook;