import DOMContentLoaded from "./DOMContentLoaded.js";
import OnLoad from "./OnLoad.js";
import OnRenderBook from "./OnRenderBook.js";

class EventsHandler {
  constructor(Main) {
      new DOMContentLoaded(Main);
      new OnLoad(Main);
      new OnRenderBook(Main);
  }
};

export default EventsHandler;