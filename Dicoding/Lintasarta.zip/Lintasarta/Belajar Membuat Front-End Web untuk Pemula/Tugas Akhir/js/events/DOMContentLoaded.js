class DOMContentLoaded {
  constructor(Main) {
    document.addEventListener('DOMContentLoaded', () => {
      const submitForm = document.getElementById('inputBook');
      submitForm.addEventListener('submit', (event) => {
          Main.addBook();
      });
  });
  }
};

export default DOMContentLoaded;