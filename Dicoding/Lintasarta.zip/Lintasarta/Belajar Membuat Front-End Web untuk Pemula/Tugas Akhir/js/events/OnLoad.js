class OnLoad {
  constructor(Main) {
    window.addEventListener('load', () => {
      if (Main.checkForStorage()) {
          if (localStorage.getItem(Main.localeStorageKey) !== null) {
              Main.bookData = JSON.parse(localStorage.getItem(Main.localeStorageKey));
              document.dispatchEvent(new Event(Main.renderEvent));
          }
        } else {
          alert('Mohon maaf, browser anda tidak mendukung Web Storage');
        }
  })
  }
};

export default OnLoad;