<?php

namespace room17\SkyBlock;

use form\FormAPI;
use form\CustomForm;
use form\SimpleForm;
use form\Form;
use form\ModalForm;

use room17\SkyBlock\{SkyBlock, SkyBlockSettings};
use room17\SkyBlock\session\{Session, SessionLocator};
use room17\SkyBlock\island\{Island, IslandManager};
use room17\SkyBlock\utils\Invitation;

use pocketmine\{Player, Server};
use pocketmine\utils\Config;

class SBUIForm {
	
	/** Var Main */
	public $playerList = [];
	
	private $plugin;
	
	private $listPlayer;
	
	public function __construct(SkyBlock $plugin) {
		$this->plugin = $plugin;
	}
	
	public function onCreateFirst($player) {
		$session = SessionLocator::getSession($player);
        if(!$session->hasIsland()) {
			$this->noHaveIsland($player);
        } else {
            $this->alreadyIsland($player);
		}
	}
	
	##############################################################################################################
	#																											 #
	#												Form Awal													 #
	#																											 #
	##############################################################################################################
	
	public function noHaveIsland($player) {
		$form = new SimpleForm(function (Player $player, $data) {
			if($data === null) {
            	return;
			}
			switch($data) {
				case 0:
					$this->islandList($player);
				break;
			}
        });
        $form->setTitle("§l§cI§fS§r§7[§l§3Sky§aBlock§r§7]");
        $form->setContent("\n                 §l§cIndo§fSkuat§r\n\n§7Hello, §o§e" . $player->getName() . "\n§6- Island§7: §cYou haven't island yet.\n\n§r§7   You have to make the island first to play §3Sky§aBlock§7 on §cIndo§fSkuat§7 Server, and if you dont understand to playing on §3Sky§aBlock§7 Server ask for help from §6Members§7 and §6Staff§7, or you can go to the tutorial area.\n\n§r§6§oWant Join Our Community?\n§r§7Follow our Social Media:\n§f- §6IG§7: @indoskuat\n§f- §6WA§7: Ask to Admin or Members\n§f- §6Discord§7: discord.io/indoskuat§r\n\n\n");
        $form->addButton("§l§8CREATE NOW\n§r§o§e>> §7Tap to Create");
        $form->sendToPlayer($player);
	}
	
	public function islandInvitationSend(Player $player, $sender) {
		$form = new ModalForm(function (Player $player, $data) use ($sender) {
            if($data === null) {
                return;
            }
            switch($data) {
				case 0:
					$senderName = $sender->getName();
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 deny $senderName");
					break;
				case 1:
					$senderName = $sender->getName();
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 accept $senderName");
				break;
			}
		});
		$form->setTitle("§c§lI§fS§r§7[§l§dINVITATION§r§7]§r");
		$form->setContent("§a" . $sender->getName() . " §ehas invited you to Island, do you want to accept it?");
		$form->setButton1("§l§2ACCEPT§r");
		$form->setButton2("§l§cDECLINE§r");
		$form->sendToPlayer($player);
	}

	public function contentIsland($player) {
		$form = new SimpleForm(function (Player $player, $data) {
            if($data === null) {
                return true;
            }
		});
		$session = SessionLocator::getSession($player);
		$island = $session->getIsland();
		$form->setTitle("§l§cI§fS§r§7[§l§3Sky§aBlock§r§7]");
			$typeIsland = ucfirst($island->getType());
		$form->setContent("         §aWelcome to your Island\n\n§e" . $player->getName() . "\n§7- §6Selected Type§7: {$typeIsland}\n\n   §7§oPlease obey server rules, and do not use Illegal Program for pleasure or break the server and §6Staff §7will §cBANNED§7 you, and please be careful to invite someone to be part of your island to avoid Griefering or taking your belongings!\n\n§r§7Need more help? ask §6Staff§7 or do §e/helpme\n\n§r§e- §8Sincerely, §cIndo§fSkuat §bTEAM§r");
		$form->sendToPlayer($player);
	}

	
	public function islandList($player) {
		$form = new SimpleForm(function (Player $player, $data) {
            if($data === null) {
                return;
            }
            switch($data) {
				case 0:
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 create shelly");
					return;
				case 1:
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 create basic");
					return;
				case 2:
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 create lost");
					return;
				case 3:
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 create palm");
				return;
			}
		});
		$form->setTitle("§l§cI§fS§r§7[§l§3Sky§aBlock§r§7]");
		$form->setContent("§e- §o§2Choose Island Type§7:\n");
		$form->addButton("§l§8Shelly\n§r§o§7Tap to Generate");
		$form->addButton("§l§8Basic\n§r§o§7Tap to Generate");
		$form->addButton("§l§8Lost\n§r§o§7Tap to Generate");
		$form->addButton("§l§8Palm\n§r§o§7Tap to Generate");
		$form->sendToPlayer($player);
	}
	
	##############################################################################################################
	#																											 #
	#												Island Form Menu											 #
	#																											 #
	##############################################################################################################
	
	public function alreadyIsland($player) {
		$form = new SimpleForm(function (Player $player, $data) {
            if($data === null) {
                return;
            }
			switch($data) {
				case 0:
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 go");
					break;
				case 1:
					$this->islandSettings($player);
					break;
				case 2:
					$this->islandLeaderboard($player);
					break;
				case 3:
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 leave");
					break;
				case 4:
					$this->islandVisit($player);
					break;
				case 5:
					$session = SessionLocator::getSession($player);  
					$rank = $session->getRank();
						if(!in_array($rank, [3])) {
							$player->sendMessage("§l§cI§fS§r§7[§3S§aB§7] §6> §cYou Dont Have Permission To Do This!");
						} else {
							$this->islandDelete($player);
						}
					break;
			}
		});
		$session = SessionLocator::getSession($player);
		$island = $session->getIsland();
		$form->setTitle("§l§cI§fS§r§7[§l§3Sky§aBlock§r§7]");
			$level = $island->getIslandLevel();
			$point = $island->getPoint();
			$state = $island->isLocked() ? "§cLocked" : "§aUnlocked";
			$memberCount = count($island->getMembers());
			$memberSlots = $island->getSlots();
			$pointNeeded = $island->getIslandLevel() * $this->plugin->getSettings()->getIslandPoint();
			$typeIsland = ucfirst($island->getType());
		$form->setContent("§7- §o§6Island Name§7: §a" . $island->getIdentifier() . "\n§r§7- §o§6Type§7: {$typeIsland}\n§r§7- §o§6Level§7: {$level}\n§r§7- §o§6Points§7: {$point}§8/§7{$pointNeeded}\n§r§7- §o§6State§7: {$state}\n§r§7- §o§6Member Count§7: §a{$memberCount}§7/§c{$memberSlots}\n§r");
		$form->addButton("§o§8GO TO SPAWN\n§e>> §7Tap here!");
		$form->addButton("§o§8SETTINGS\n§e>> §7Tap here!");
		$form->addButton("§o§8LEADERBOARD\n§e>> §7Tap here!");
		$form->addButton("§o§8LEAVE\n§e>> §7Tap here!");
		$form->addButton("§o§8VISIT\n§e>> §7Tap here!");
		$form->addButton("§o§8DISBAND/DELETE ISLAND\n§e>> §7Tap here!");
		$form->sendToPlayer($player);
	}
	
	##############################################################################################################
	#																											 #
	#												Settings Form												 #
	#																											 #
	##############################################################################################################
	
	public function islandSettings($player) {
		$form = new SimpleForm(function (Player $player, $data) {
            if($data === null) {
                return;
            }
			switch($data) {
				case 0:
					$session = SessionLocator::getSession($player);  
					$rank = $session->getRank();
						if(!in_array($rank, [3])) {
							$player->sendMessage("§l§cI§fS§r§7[§3S§aB§7] §6> §cYou Dont Have Permission To Do This!");
						} else {
							$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 setspawn");
						}
					break;
				case 1:
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 chat");
					break;
				case 2:
					$session = SessionLocator::getSession($player);  
					$rank = $session->getRank();
						if(!in_array($rank, [2, 3])) {
							$player->sendMessage("§l§cI§fS§r§7[§3S§aB§7] §6> §cYou Dont Have Permission To Do This!");
						} else {
							$this->islandCooperate($player);
						}
					break;
				case 3:
					$session = SessionLocator::getSession($player);  
					$rank = $session->getRank();
						if(!in_array($rank, [2, 3])) {
							$player->sendMessage("§l§cI§fS§r§7[§3S§aB§7] §6> §cYou Dont Have Permission To Do This!");
						} else {
							$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 lock");
						}
					break;
				case 4:
					$session = SessionLocator::getSession($player);  
					$rank = $session->getRank();
						if(!in_array($rank, [1, 2, 3])) {
							$player->sendMessage("§l§cI§fS§r§7[§3S§aB§7] §6> §cYou Dont Have Permission To Do This!");
						} else {
							$this->islandMembers($player);
						}
					break;
				case 5:
					$session = SessionLocator::getSession($player);  
					$rank = $session->getRank();
						if(!in_array($rank, [3])) {
							$player->sendMessage("§l§cI§fS§r§7[§3S§aB§7] §6> §cYou Dont Have Permission To Do This!");
						} else {
							$this->islandInvite($player);
						}
					break;
				case 6:
					$this->alreadyIsland($player);
				break;
			}
		});
		$form->setTitle("§l§cI§fS§r§7[§l§3Sky§aBlock§r§7]");
		$form->addButton("§o§8SETSPAWN\n§e>> §7Tap here!");
		$form->addButton("§o§8CHAT\n§e>> §7Tap here!");
		$form->addButton("§o§8COOPERATE\n§e>> §7Tap here!");
        $form->addButton("§o§8STATE\n§e>> §7Tap here!");
		$form->addButton("§o§8MEMBERS\n§e>> §7Tap here!");
		$form->addButton("§o§8INVITE\n§e>> §7Tap here!");
		$form->addButton("§l§o§cBack§r");
		$form->sendToPlayer($player);
	}
	
	/*
	*
	*	Members Settings
	*
	*/
	
	public function islandMembers($player) {
		$form = new SimpleForm(function(Player $player, $data) {
		    $result = $data;
		    if($result === null){
		        return true;
		    }
		    if($result === "back") {
				$this->islandSettings($player);
		        return true;
		    }
		    $this->islandMembersSetting($player, $result);
		});
		$session = SessionLocator::getSession($player);
		$island = $session->getIsland(); 
		$form->setTitle("§l§cI§fS§r§7[§3S§aB§7] §6> §bMembers");
		foreach($island->getMembers() as $member){
		    $memberSession = $member->getOnlineSession();
            if($memberSession != null) {
                $form->addButton("§6> §o§8{$memberSession->getName()}§r\n§aOnline§r", -1, "", $memberSession->getName());
            } else {
                $form->addButton("§6> §o§8{$member->getLowerCaseName()}§r\n§cOffline§r", -1, "", $member->getLowerCaseName()); 
            }
		}
		$form->addButton("§l§cBack", -1, "", "back");
		$form->sendToPlayer($player); 
    }
	
	public function islandMembersSetting($player, $member){
		$form = new SimpleForm(function (Player $player, $data) use ($member){
		    $result = $data;
		    if($result === null) {
		        return true;
		    }
		    $session = SessionLocator::getSession($player);
		    $island = $session->getIsland();
		    switch($result){
		    case 0:
				$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 kick $member"); 
				break;
		    case 1:
				$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 promote $member"); 
				break;
		    case 2:
				$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 demote $member");
				break;
			case 3:
				$this->islandMembers($player);
			break;
		    }
		});
		$session = SessionLocator::getSession($player);
		$island = $session->getIsland();
		$form->setTitle("§2Manage §6>§d {$member}§r");
		$form->setContent("§7What do you want to do to §6{$member}§r?\n\n");
		$form->addButton("§o§8KICK\n§e>> §7Tap here!");
		$form->addButton("§o§8PROMOTE\n§e>> §7Tap here!");
		$form->addButton("§o§8DEMOTE\n§e>> §7Tap here!");
		$form->addButton("§l§cBack");
		$form->sendToPlayer($player);  
    }
	
	/*
	*
	*
	*	Member Settings End Line
	*
	*/
	
	public function islandVisit($player) {
		$list = [];
        foreach($this->plugin->getServer()->getOnlinePlayers() as $p){
            $list[] = $p->getName();
        }
        $this->playerList[$player->getName()] = $list;
		$form = new CustomForm(function(Player $player, $data) {
			if($data == null) {
				return true;
			}
			$index = $data[1];
            $playerName = $this->playerList[$player->getName()][$index];
			$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 visit {$playerName}");
		});
		$form->setTitle("§l§cI§fS§r§7[§l§3Sky§aBlock§r§7]");
		$form->addLabel("§o§2Select a Player to visit the island§7: \n\n");
		$form->addDropDown("§6- Select Player§7:§r", $this->playerList[$player->getName()]);
		$form->sendToPlayer($player);
	}
	
	##############################################################################################################
	#																											 #
	#												Settings List												 #
	#																											 #
	##############################################################################################################
	
	public function islandInvite($player) {
		$list = [];
        foreach($this->plugin->getServer()->getOnlinePlayers() as $p){
            $list[] = $p->getName();
        }
        $this->playerList[$player->getName()] = $list;
		$form = new CustomForm(function(Player $player, $data) {
			if($data == null) {
				return true;
			}
			$index = $data[1];
            $playerName = $this->playerList[$player->getName()][$index];
			$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 invite {$playerName}");
		});
		$form->setTitle("§l§cI§fS§r§7[§l§3Sky§aBlock§r§7]");
		$form->addLabel("§o§2Select a Player to be part of your island§7: \n\n");
		$form->addDropDown("§6- Select Player§7:§r", $this->playerList[$player->getName()]);
		$form->sendToPlayer($player);
	}
	
	public function islandCooperate($player) {
		$list = [];
        foreach($this->plugin->getServer()->getOnlinePlayers() as $p){
            $list[] = $p->getName();
        }
        $this->playerList[$player->getName()] = $list;
		$form = new CustomForm(function(Player $player, $data) {
			if($data == null) {
				return true;
			}
			$index = $data[1];
            $playerName = $this->playerList[$player->getName()][$index];
			$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 cooperate {$playerName}");
		});
		$form->setTitle("§l§cI§fS§r§7[§l§3Sky§aBlock§r§7]");
		$form->addLabel("§o§2Select a Player to work with on your island§7: \n\n");
		$form->addDropDown("§6- Select Player§7:§r", $this->playerList[$player->getName()]);
		$form->sendToPlayer($player);
	}
	
	public function islandDelete($player) {
		$form = new ModalForm(function(Player $player, $data) {
			if($data == null) {
				return;
			}
			switch($data) {
				case 0:
					$this->alreadyIsland($player, "");
					break;
				case 1:
					$this->plugin->getServer()->getCommandMap()->dispatch($player, "isbb1321 disband");
				break;
			}
		});
		$form->setTitle("§l§cI§fS§r§7[§a§lCONFIRMATION§r§7]");
		$form->setContent("§aAre You Sure Want To Delete Island?\n§o§cIt will reset & delete All Data(World, Members, Level, Point)");
		$form->setButton1("§2Confirm");
		$form->setButton2("§cCancel");
		$form->sendToPlayer($player);
	}
	
	##############################################################################################################
	#																											 #
	#												Leaderboard												 	 #
	#																											 #
	##############################################################################################################
	
	public function islandLeaderboard(Player $player) {
		$form = new SimpleForm(function (Player $player, $data){
		    $result = $data;
		    if($result !== null){
		        $this->alreadyIsland($player);
		    }
		});
		$form->setTitle("§l§cI§fS§r§7[§l§3Sky§aBlock§r§7]");
			$isContent = "";
			$dat = SkyBlock::getInstance()->getAllIslandData("level");
			arsort($dat);
			$i = 0;
			foreach($dat as $island => $value) {
				if($i >= 10) {
					break;
				}
				$i++;
				if($i == 1) {
					$isContent .= "§a{$i}§7. §a{$island} §7- Level: §a{$value}\n";
				} elseif($i == 2) {
					$isContent .= "§b{$i}§7. §b{$island} §7- Level: §a{$value}\n";
				} elseif($i == 3) {
					$isContent .= "§e{$i}§7. §e{$island} §7- Level: §a{$value}\n";
				} elseif($i >= 4)	{
					$isContent .= "§7{$i}. §6{$island} §7- Level: §a{$value}\n";
				}
			}
		$form->setContent("             §o§6Top Island Level§r\n\n".$isContent."\n");
		$form->addButton("§c§lBack");
		$form->sendToPlayer($player); 
    } 

	##############################################################################################################
	#																											 #
	#													Pembatas												 #
	#																											 #
	##############################################################################################################
}