<?php
/**
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

declare(strict_types=1);

namespace room17\SkyBlock\command\presets;


use room17\SkyBlock\command\IslandCommand;
use room17\SkyBlock\command\IslandCommandMap;
use room17\SkyBlock\session\Session;
use room17\SkyBlock\utils\message\MessageContainer;
use room17\SkyBlock\SBUIForm; 
use room17\SkyBlock\SkyBlock;

class LeaderboardCommand extends IslandCommand {

    /** @var IslandCommandMap */
    private $map;

    public function __construct(IslandCommandMap $map) {
        $this->map = $map;
    }

    public function getName(): string {
        return "leaderboard";
    }

    public function getAliases(): array {
        return ["lead"];
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("HELP_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("HELP_DESCRIPTION");
    } 

    public function onCommand(Session $session, array $args): void {
        $form = new SBUIForm(SkyBlock::$instance);
        $form->islandLeaderboard($session->getPlayer());
    }
}