# IndoSkuat-App
Java App Webview www.indoskuat.net
