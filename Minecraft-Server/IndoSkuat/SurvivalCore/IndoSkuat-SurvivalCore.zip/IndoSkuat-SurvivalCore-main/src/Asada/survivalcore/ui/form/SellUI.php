<?php

namespace Asada\survivalcore\ui\form;

use Asada\survivalcore\{SurvivalCore, Utils};
use Asada\survivalcore\libs\formapi\FormAPI;

use pocketmine\Player;
use pocketmine\item\Item;

use onebone\economyapi\EconomyAPI;

class SellUI {
	
	public $plugin;
	
	private $form;
	private $config;
	private $configArray;
	private $formTitle = "§l§8SURVIVAL";
	
	public function __construct(SurvivalCore $plugin) {
		$this->plugin = $plugin;
		
		$this->form = new FormAPI();
		$this->config = (new Utils($plugin))->getSellUIConfig();
		$this->configArray = (new Utils($plugin))->getSellUIConfig()->getAll();
	}
	
	public function replaceVars($str, array $vars) : string{
        foreach($vars as $key => $value){
            $str = str_replace("{" . $key . "}", $value, $str);
        }
        return $str;
    }
	
	public function mainSellUI($player) {
		$form = $this->form->createSimpleForm(function(Player $player, $result) {
			if($result == null) {
				return;
			} elseif($result === "sellhand") {
				$this->sellHandUI($player);
				return;
			} elseif($result === "sellall") {
				$this->sellAllUI($player);
				return;
			} elseif($result === "sellinv") {
				$this->sellInventoryUI($player);
				return;
			}
		});
		
		$form->setTitle($this->formTitle);
		$form->setContent("§7Choose:");
		$form->addButton("§l§8Sell Hand", -1, "", "sellhand");
		if($player->hasPermission("survival.sell.all")) {
			$form->addButton("§l§8Sell All", -1, "", "sellall");
		} elseif(!$player->hasPermission("survival.sell.all")) {
			$form->addButton("§l§8Sell All§r\n§cYou don't have permission", -1, "", "sellall");
		}
		if($player->hasPermission("survival.sell.all")) {
			$form->addButton("§l§8Sell Inventory", -1, "", "sellinv");
		} elseif(!$player->hasPermission("survival.sell.all")) {
			$form->addButton("§l§8Sell Inventory§r\n§cYou don't have permission", -1, "", "sellinv");
		}
		$form->sendToPlayer($player);
	}
	
	public function sellHandUI($player) {
		$form = $this->form->createModalForm(function(Player $player, $result) {
			if($result == null) {
				return;
			} elseif($result == 1) {
				$item = $player->getInventory()->getItemInHand();
				if(isset($this->configArray[$item->getID() . ":" . $item->getDamage()])) {
					$price = $this->configArray[$item->getID() . ":" . $item->getDamage()];
					$count = $item->getCount();
					$totalPrice = $price * $count;
					$item->setCount($item->getCount() - (int)$count);
					$player->getInventory()->setItemInHand($item);
					EconomyAPI::getInstance()->addMoney($player->getName(), $totalPrice);
					$player->sendMessage($this->replaceVars($this->config->get("Success-Sell"), [
                        "AMOUNT" => (string)$count,
                        "ITEMNAME" => $item->getName(),
                        "MONEY" => (string)$totalPrice]
					));
					return;
				} elseif(isset($this->configArray[$item->getID()])) {
					$price = $this->configArray[$item->getID()];
					$count = $item->getCount();
					$totalPrice = $price * $count;
					$item->setCount($item->getCount() - (int)$count);
					$player->getInventory()->setItemInHand($item);
					EconomyAPI::getInstance()->addMoney($player->getName(), $totalPrice);
					$player->sendMessage($this->replaceVars($this->config->get("Success-Sell"), [
                        "AMOUNT" => (string)$count,
                        "ITEM" => $item->getName(),
                        "PRICE" => (string)$totalPrice]
					));
					return;
				}
				$player->sendMessage(str_replace("{ITEM}", $player->getInventory()->getItemInHand()->getName(), $this->config->get("Not-For-Sell")));
				return;
			} elseif($result == 2) {
				$this->mainSellUI($player);
				return;
			}
		});
		
		$form->setTitle($this->formTitle);
		$form->setContent("§eDo you really want to sell item on your hand?");
		$form->setButton1("§6YES");
		$form->setButton2("§cCANCEL");
		$form->sendToPlayer($player);
	}
	
	public function sellAllUI($player) {
		$form = $this->form->createModalForm(function(Player $player, $result) {
			if($result == null) {
				return;
			} elseif($result == 1) {
				$item = $player->getInventory()->getItemInHand();
                $inventory = $player->getInventory();
                $contents = $inventory->getContents();
                if(isset($this->configArray[$item->getID() . ":" . $item->getDamage()])) {
					$price = $this->configArray[$item->getID() . ":" . $item->getDamage()];
					$count = 0;
					foreach($contents as $slot){
						if($slot->getID() == $item->getId()){
							$count = $count + $slot->getCount();
								$inventory->remove($slot);
						}
					}
					$inventory->sendContents($player);
					$totalprice = $count * $price;
					EconomyAPI::getInstance()->addMoney($player->getName(), (int)$totalprice);
					$player->sendMessage($this->replaceVars($this->config["Success-Sell"], [
						"AMOUNT" => (string)$count,
						"ITEM" => $item->getName(),
						"PRICE" => (string)$totalprice]));
					return;
				} elseif(isset($this->configArray[$item->getID()])) {
					$price = $this->configArray[$item->getID()];
					$count = 0;
					foreach($contents as $slot){
						if($slot->getID() == $item->getId()){
							$count = $count + $slot->getCount();
								$inventory->remove($slot);
						}
					}
					$inventory->sendContents($player);
					$totalprice = $count * $price;
					EconomyAPI::getInstance()->addMoney($player->getName(), (int)$totalprice);
					$player->sendMessage($this->replaceVars($this->config->get("Success-Sell"), [
						"AMOUNT" => (string)$count,
						"ITEM" => $item->getName(),
						"PRICE" => (string)$totalprice]));
					return;
				}
				$player->sendMessage(str_replace("{ITEM}", $player->getInventory()->getItemInHand()->getName(), $this->config->get("Not-For-Sell")));
				return;
			} elseif($result == 2) {
				$this->mainSellUI($player);
				return;
			}
		});
		
		$form->setTitle($this->formTitle);
		$form->setContent("§eDo you really want to sell all item type like on your hand in your inventory?");
		$form->setButton1("§6YES");
		$form->setButton2("§cCANCEL");
		$form->sendToPlayer($player);
	}
	
	public function sellInventoryUI($player) {
		$form = $this->form->createModalForm(function(Player $player, $result) {
			if($result == null) {
				return;
			} elseif($result == 1) {
				$inv = $player->getInventory()->getContents();
                $revenue = 0;
				foreach($inv as $item){
					if(isset($this->configArray[$item->getID() . ":" . $item->getDamage()])) {
						$revenue = $revenue + ($item->getCount() * $this->configArray[$item->getID() . ":" . $item->getDamage()]);
						$player->getInventory()->remove($item);
					} elseif(isset($this->configArray[$item->getID()])) {
						$revenue = $revenue + ($item->getCount() * $this->configArray[$item->getID()]);
						$player->getInventory()->remove($item);
					}
				}
				if($revenue <= 0){
					$player->sendMessage($this->config->get("Inventory-Not-Found"));
					return;
				}
				EconomyAPI::getInstance()->addMoney($player->getName(), (int)$revenue);
				$player->sendMessage($this->replaceVars($this->config->get("Success-Sell-Inventory"), [
					"PRICE" => (string)$revenue]));
				return;
			} elseif($result == 2) {
				$this->mainSellUI($player);
				return;
			}
		});
		
		$form->setTitle($this->formTitle);
		$form->setContent("§eDo you really want to sell all item sellable on your inventory?");
		$form->setButton1("§6YES");
		$form->setButton2("§cCANCEL");
		$form->sendToPlayer($player);
	}
}