<?php

namespace Asada\survivalcore\ui\form;

use Asada\survivalcore\{SurvivalCore, Utils};
use Asada\survivalcore\libs\formapi\FormAPI;

class InfoUI {
	
	private $plugin;
	
	private $formapi;
	private $config;
	private $formTitle = "§l§8SURVIVAL";
	
	public function __construct(SurvivalCore $plugin) {
		$this->plugin = $plugin;
		
		$this->formapi = new FormAPI();
		$this->config = (new Utils($this->plugin))->getInfoUIConfig();
	}
	
	
	public function mainInfoUI($player) {
		$form = $this->formapi->createSimpleForm(function($player, $result) {
			if($result == null) {
				return;
			} elseif($result === "rules") {
				$this->rulesUI($player);
			} elseif($result === "help") {
				$this->helpUI($player);
			} elseif($result === "membership") {
				$this->membershipUI($player);
			}
		});
		$form->setTitle($this->formTitle);
		$form->setContent("§7Choose");
		$form->addButton("§l§8RULES", -1, "", "rules");
		$form->addButton("§l§8HELP & TUTORIAL", -1, "", "help");
		$form->addButton("§l§8MEMBERSHIP", -1, "", "membership");
		$player->sendForm($form);
	}
	
	//*** [ RULES ] ***\\
	public function rulesUI($player) {
		$form = $this->formapi->createSimpleForm(function($player, $result) {
			if($result == null) {
				return;
			} elseif($result === "back") {
				$this->mainInfoUI($player);
			}
		});
		$form->setTitle($this->formTitle);
		$form->setContent($this->config->get("RulesUI-Content"));
		$form->addButton("§cBack", -1, "", "back");
		$player->sendForm($form);
	}
	
	//*** [ HELP & TUTORIAL] ] ***\\
	public function mainHelpUI($player) {
		$form = $this->formapi->createSimpleForm(function($player, $result) {
			if($result == null) {
				return;
			} elseif($result === "back") {
				$this->mainInfoUI($player);
			}
		});
		$form->setTitle($this->formTitle);
		$form->setContent($this->config->get("MainHelpUI-Content"));
		$form->addButton("§cBack", -1, "", "back");
		$player->sendForm($form);
	}
	
	//*** [ RANKS ] ***\\
	public function mainRanksUI($player) {
		$config = $this->config->getAll();
		$form = $this->formapi->createSimpleForm(function($player, $result) {
			if($result == null) {
				return;
			} elseif($result === "back") {
				$this->mainInfoUI($player);
			} else {
				$this->infoRankUI($player, $result);
			}
		});
		$form->setTitle($this->formTitle);
		$form->setContent("§7Choose:");
		foreach($config["Ranks"] as $ranks) {
			$rankName = $ranks["name"];
			$form->addButton("§l§8" . $config["Ranks"][$rankName]["name"], $config["Ranks"][$rankName]["img-type"], $config["Ranks"][$rankName]["img"], $rankName);
		}
		$form->addButton("§cBack", -1, "", "back");
		$player->sendForm($form);
	}
	
	public function infoRankUI($player, $rankName) {
		$config = $this->config->getAll();
		$form = $this->formapi->createSimpleForm(function($player, $result) {
			if($result == null) {
				return;
			} elseif($result === "back") {
				$this->mainRanksUI($player);
			}
		});
		$form->setTitle($this->formTitle);
		$form->setContent($config["Ranks"][$rankName]["content"]);
		$form->addButton("§cBack", -1, "", "back");
		$player->sendForm($form);
	}
}