<?php

namespace Asada\survivalcore\listener;

use Asada\survivalcore\{SurvivalCore, Utils};
use Asada\survivalcore\ui\form\FirstTimeJoinUI;

use pocketmine\event\Listener;
use pocketmine\event\player\{PlayerJoinEvent, PlayerQuitEvent, PlayerPreLoginEvent};

class JoinQuitEvent implements Listener{
	
	public $plugin;
	
	public function __construct(SurvivalCore $plugin){
		$this->plugin = $plugin;
	}
	
	public function onPlayerJoin(PlayerJoinEvent $event) {
		$player = $event->getPlayer();
		$playerName = $player->getName();
		
		$utils = new Utils($this->plugin);
		$config = $utils->getJoinQuitConfig();
		$configArray = $config->getAll();
		if(!$player->hasPermission("survival.termsandcondition.passed")) {
			(new FirstTimeJoinUI($this->plugin))->mainUI($player);
			$event->setJoinMessage("");
		}
		if($config->get("Type-JoinMessage") === "normal") {
			$getMessage = $config->get("JoinMessage");
			$message = str_replace("{player}", $playerName, $getMessage);
			$event->setJoinMessage($message);
		} elseif($config->get("Type-JoinMessage") === "permission") {
			foreach($configArray["per-permission"] as $perPermission => $data) {
				if($player->hasPermission($data["permission"])) {
					$message = $data["message"];
					$event->setJoinMessage($message);
				}
			}
		}
	}
	
	public function onPlayerQuit(PlayerQuitEvent $event) {
		$player = $event->getPlayer();
		$playerName = $player->getName();
		
		$utils = new Utils($this->plugin);
		$config = $utils->getJoinQuitConfig();
		
		if($config->get("Enable-QuitMessage") == true) {
			$getMessage = $config->get("QuitMessage");
			$message = str_replace("{player}", $playerName, $getMessage);
			$event->setQuitMessage($message);
		} else {
			$event->setQuitMessage("");
		}
	}
	
	public function onPlayerLogin(PlayerPreLoginEvent $event) {
		$player = $event->getPlayer();
		$playerName = $player->getName();
		
		$utils = new Utils($this->plugin);
		$config = $utils->getJoinQuitConfig();
		
		if($config->get("Enable-ForceProxy") == true) {
			if($player->getAddress() !== $config->get("ForcePlayerIP")) {
				$player->kick($config->get("KickMessage"));
			}
		}
		
		if($config->get("Enable-Whitelist") == true) {
			$player->kick($config->get("WhitelistMessage"));
		}
	}
	
}