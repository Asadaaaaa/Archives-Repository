<?php

namespace Asada\survivalcore\listener;

use Asada\survivalcore\{SurvivalCore, Utils};

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\level\Position;

class PortalsSurvivalEvent implements Listener{
	
	public $plugin;
	
	public function __construct(SurvivalCore $plugin){
		$this->plugin = $plugin;
	}
	
	public function onPlayerMove(PlayerMoveEvent $event) {
		$player = $event->getPlayer();
		$playerName = $player->getName();
		
		$utils = new Utils($this->plugin);
		$config = $utils->getPortalsSurvivalConfig();
		
		// Player Data
		$playerWorld = $player->getLevel()->getFolderName();
		$x = round($player->x);
		$y = round($player->y);
		$z = round($player->z);
		
		// Portals Data
		$portalsWorld = $config->get("Portals-World");
		$x1 = min((int)$config->get("Portals-x1"), (int)$config->get("Portals-x2"));
		$y1 = min((int)$config->get("Portals-y1"), (int)$config->get("Portals-y2"));
		$z1 = min((int)$config->get("Portals-z1"), (int)$config->get("Portals-z2"));
		$x2 = max((int)$config->get("Portals-x1"), (int)$config->get("Portals-x2"));
		$y2 = max((int)$config->get("Portals-y1"), (int)$config->get("Portals-y2"));
		$z2 = max((int)$config->get("Portals-z1"), (int)$config->get("Portals-z2"));
		
		$survivalWorld = $this->plugin->getServer()->getLevelByName($config->get("Survival-World"));
		
		if(!$event->getFrom()->equals($event->getTo()) && $event->getTo()->distanceSquared($event->getFrom()) > 0.01){
            if($playerWorld === $portalsWorld && $x >= $x1 && $x <= $x2 && $y >= $y1 && $y <= $y2 && $z >= $z1 && $z <= $z2) {
				$player->teleport(new Position((int)$config->get("x"), (int)$config->get("y"), (int)$config->get("z"), $survivalWorld));
				$player->sendMessage("Haloooooooooooooooooooooo");
			}
        }
	}
	
}