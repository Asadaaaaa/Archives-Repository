<?php

namespace Asada\survivalcore\task;

// Call this Plugin
use Asada\survivalcore\{SurvivalCore, Utils};
use Asada\survivalcore\ui\form\FirstTimeJoinUI;

// Call Framework
use pocketmine\Player;
use pocketmine\scheduler\Task;

class FirstTimeJoinTask extends Task {
	
	private $plugin;
	private $player;
	
	private $timer = 0;
	
	public function __construct(SurvivalCore $plugin, $player) {
		$this->plugin = $plugin;
		$this->player = $player;
	}
	
	public function onRun(int $currentTick) {
		$playerName = $this->player->getName();
		$data = $this->plugin->sessionTask;
		if(isset($data[$playerName])) {
			$this->timer++;
			$this->plugin->getServer()->getLogger()->info("Woy {$this->timer} detik");
			if($this->timer == 6) {
				$data = $this->plugin->sessionTask;
				$data[$playerName]["status"] = "Readed";
				$this->plugin->sessionTask = $data;
			}
		} elseif(!isset($data[$playerName])) {
			$this->plugin->getScheduler()->cancelTask($this->getTaskId());
		}
	}
}