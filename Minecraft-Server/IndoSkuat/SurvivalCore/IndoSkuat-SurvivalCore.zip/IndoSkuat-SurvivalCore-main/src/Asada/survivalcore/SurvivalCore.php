<?php

namespace Asada\survivalcore;

use pocketmine\Server;
use pocketmine\plugin\PluginBase;

use Asada\survivalcore\Utils;
use Asada\survivalcore\listener\{JoinQuitEvent, AnvilInteractEvent, PortalsSurvivalEvent};
use Asada\survivalcore\command\{HubCommand, InfoUICommand, ShopUICommand, SellUICommand};
use Asada\survivalcore\task\HubTeleportTask;

class SurvivalCore extends PluginBase {
	
	public $sessionTask = [];
	
	public function onLoad() {
		$this->saveResource("JoinQuit.yml");
		$this->saveResource("HubConfiguration.yml");
		$this->saveResource("PortalsSurvival.yml");
		$this->saveResource("ui/form/InfoUIConfiguration.yml");
		$this->saveResource("ui/form/ShopUIConfiguration.yml");
		$this->saveResource("ui/form/AnvilUIConfiguration.yml");
		$this->saveResource("ui/form/SellUIConfiguration.yml");
		$this->saveResource("ui/form/FirstTimeJoinConfiguration.yml");
	}
	
	public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents(new JoinQuitEvent($this), $this);
		$this->getServer()->getPluginManager()->registerEvents(new AnvilInteractEvent($this), $this);
		$this->getServer()->getPluginManager()->registerEvents(new PortalsSurvivalEvent($this), $this);
		$this->getServer()->getCommandMap()->register("Hub", new HubCommand($this));
		$this->getServer()->getCommandMap()->register("Info", new InfoUICommand($this));
		$this->getServer()->getCommandMap()->register("Shop", new ShopUICommand($this));
		$this->getServer()->getCommandMap()->register("Sell", new SellUICommand($this));
		
		// Load World
		$this->getServer()->loadLevel((new Utils($this))->getPortalsSurvivalConfig()->get("Survival-World"));
		
		// Time
		$this->getServer()->getDefaultLevel()->setTime(9000);
		$this->getServer()->getDefaultLevel()->stopTime();
	}
	
}