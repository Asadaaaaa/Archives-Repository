<?php

namespace Asada\survivalcore\task;

// Call this Plugin
use Asada\survivalcore\{SurvivalCore, Utils};

// Call Framework
use pocketmine\Player;
use pocketmine\level\sound\PopSound;
use pocketmine\scheduler\Task;

class HubTeleportTask extends Task {
	
	private $plugin;
	private $player;
	
	private $timer;
	
	public function __construct(SurvivalCore $plugin, $player, int $timer) {
		$this->plugin = $plugin;
		$this->player = $player;
		$this->timer = $timer + 1;
	}
	
	public function onRun(int $currentTick) {
		$config = (new Utils($this->plugin))->getHubConfig();
		$this->timer--;
		$this->player->addTitle("§bTeleporting in");
		$this->player->addSubTitle("§a" . $this->timer . " §7seconds");
		$this->player->getLevel()->addSound(new PopSound($this->player));
		if($this->timer == 0) {
			$this->player->addTitle("§aTeleported", "§7Succesfully", 10, 20, 10);
			$this->player->teleport($this->plugin->getServer()->getDefaultLevel()->getSafeSpawn());
			$this->plugin->getScheduler()->cancelTask($this->getTaskId());
		}
	}
}