<?php

namespace Asada\survivalcore\ui\form;

use Asada\survivalcore\{SurvivalCore, Utils};
use Asada\survivalcore\libs\formapi\FormAPI;
use Asada\survivalcore\task\FirstTimeJoinTask;

use pocketmine\command\ConsoleCommandSender;

class FirstTimeJoinUI {
	
	private $plugin;
	
	private $formapi;
	private $config;
	
	
	
	public function __construct(SurvivalCore $plugin) {
		$this->plugin = $plugin;
		
		$this->formapi = new FormAPI();
		$this->config = (new Utils($this->plugin))->getFirsTimeJoinConfig();
	}
	
	public function mainUI($player) {
		$playerName = $player->getName();
		$form = $this->formapi->createModalForm(function($player, $result) {
			if($result == null) {
				return;
			} elseif($result == 1) {
				$this->firstTimeJoinUI($player, "§l§8SURVIVAL");
				$this->plugin->getScheduler()->scheduleRepeatingTask(new FirstTimeJoinTask($this->plugin, $player), 20);
			} elseif($result === "help") {
				$this->rulesUI($player);
			}
		});
		$form->setTitle("§l§8SURVIVAL");
		$form->setContent(str_replace("{PLAYER}", $playerName, $this->config->get("Main-Content")));
		$form->setButton1("§8This is my first time");
		$form->setButton2("§8I've played before");
		$player->sendForm($form);
	}
	
	public function firstTimeJoinUI($player, $content) {
		$playerName = $player->getName();
		
		$data = [];
		$data[$playerName] = ["status" => "Reading"];
		$this->plugin->sessionTask = $data;
		
		$form = $this->formapi->createSimpleForm(function($player, $result) use ($playerName) {
			if($result == null) {
				$data = $this->plugin->sessionTask;
				unset($data[$playerName]);
				$this->plugin->sessionTask = $data;
				$this->firstTimeJoinUI($player, "§l§cYOU CAN'T SKIP THIS");
				$this->plugin->getScheduler()->scheduleRepeatingTask(new FirstTimeJoinTask($this->plugin, $player), 20);
				return;
			} elseif($result == 0) {
				$data = $this->plugin->sessionTask;
				if($data[$playerName]["status"] == "Reading") {
					unset($data[$playerName]);
					$this->plugin->sessionTask = $data;
					$this->firstTimeJoinUI($player, "§l§cPLEASE READ TEXT BELOW");
					$this->plugin->getScheduler()->scheduleRepeatingTask(new FirstTimeJoinTask($this->plugin, $player), 20);
					return;
				} elseif($data[$playerName]["status"] == "Readed") {
					unset($data[$playerName]);
					$this->plugin->sessionTask = $data;
					$this->rulesUI($player);
					return;
				}
				return;
			}
		});
		$form->setTitle($content);
		$form->setContent(str_replace("{PLAYER}", $playerName, $this->config->get("FirstTimeJoin-Content")));
		$form->addButton("§l§8NEXT >>>");
		$player->sendForm($form);
	}
	
	public function rulesUI($player) {
		$form = $this->formapi->createSimpleForm(function($player, $result) {
			if($result == null) {
				$this->rulesUI($player);
				return;
			} elseif($result == 0) {
				$this->termsAndCondition($player);
			}
		});
		$form->setTitle("§l§8SURVIVAL");
		$form->setContent($this->config->get("Rules-Content"));
		$form->addButton("§l§8NEXT >>>");
		$player->sendForm($form);
	}
	
	public function termsAndCondition($player) {
		$playerName = $player->getName();
		$form = $this->formAPI->createSimpleForm(function($player, $result) {
			if($result == null) {
				$this->termsAndCondition($player);
				return;
			} elseif($result == 0) {
				$this->plugin->getServer()->dispatchComannd(new ConsoleCommandSender(), "setuperms {$playerName} survival.termsandcondition.passed");
				return;
			} elseif($result == 1) {
				$player->kick();
				return;
			}
		});
		$form->setTitle("§l§8SURVIVAL");
		$form->setContent($this->config->get("TermsAndCondition-Content"));
		$form->addButton("§l§6Yes, I Agree");
		$form->addButton("§l§cNo, I Disagree");
		$player->sendForm($form);
	}
	
}