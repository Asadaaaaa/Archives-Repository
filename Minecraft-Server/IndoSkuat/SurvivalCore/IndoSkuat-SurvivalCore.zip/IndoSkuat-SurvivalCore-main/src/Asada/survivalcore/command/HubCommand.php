<?php

namespace Asada\survivalcore\command;

// Call This Plugin
use Asada\survivalcore\{SurvivalCore, Utils};
use Asada\survivalcore\task\HubTeleportTask;

// Call Frame Work
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender, PluginIdentifiableCommand};
use pocketmine\plugin\Plugin;

class HubCommand extends Command implements PluginIdentifiableCommand {

    /** @var Main */
    public $plugin;

    public function __construct(SurvivalCore $plugin) {
        $this->plugin = $plugin;
        parent::__construct("hub", "Back to Main Spawn", null);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args){
		$utils = new Utils($this->plugin);
		$config = $utils->getHubConfig();
        if($sender instanceof Player) {
			$this->plugin->getScheduler()->scheduleRepeatingTask(new HubTeleportTask($this->plugin, $sender, $config->get("Delay")), 20);
		}else{
			$sender->sendMessage("§l§7BOT §r§6>§b> §o§e/hub §cCommand only work in game.");
		}
    }

    public function getPlugin(): Plugin {
        return $this->plugin;
    }
}