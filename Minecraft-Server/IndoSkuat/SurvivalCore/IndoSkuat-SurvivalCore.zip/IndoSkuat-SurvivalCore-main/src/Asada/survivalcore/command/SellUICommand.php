<?php

namespace Asada\survivalcore\command;

use Asada\survivalcore\SurvivalCore;
use Asada\survivalcore\ui\form\SellUI;

// Call Frame Work
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender, PluginIdentifiableCommand};
use pocketmine\plugin\Plugin;

class SellUICommand extends Command implements PluginIdentifiableCommand {
	
	private $plugin;
	
	public function __construct (SurvivalCore $plugin) {
		$this->plugin = $plugin;
		parent::__construct("sell", "Sell your item and get money", null);
	}
	
	public function execute(CommandSender $sender, string $commandLabel, array $args){
        #if($sender instanceof Player) {
			(new SellUI($this->plugin))->mainSellUI($sender);
		#}else{
			#$sender->sendMessage("§l§7BOT §r§6>§b> §o§e/info §cCommand only work in game.");
		#}
    }

    public function getPlugin(): Plugin {
        return $this->plugin;
    }
}