<?php

namespace Asada\survivalcore\ui\form;

// Call Main
use Asada\survivalcore\{SurvivalCore, Utils};
// Call libs Form
use Asada\survivalcore\libs\formapi\FormAPI;

// Call Frame Work
use pocketmine\item\{Item, Tool, Armor};
use pocketmine\Player;

use onebone\economyapi\EconomyAPI;

class AnvilUI {
	
	private $plugin;
	
	private $form;
	private $config;
	private $formTitle = "§l§8SURVIVAL";

    public function __construct(SurvivalCore $plugin){
		$this->plugin = $plugin;
		
		$this->form = new FormAPI();
		$this->config = (new Utils($plugin))->getAnvilUIConfig();
    }
	
	public function alphanum($string) {
        if (function_exists('ctype_alnum')) {
            $return = ctype_alnum($string);
        } else {
            $return = preg_match('/^[a-z0-9]+$/i', $string) > 0;
        }
        return $return;
    }
	
	public function mainAnvilUI($player, $content) {
		$form = $this->form->createSimpleForm(function(Player $player, $result) {
			$item = $player->getInventory()->getItemInHand();
			if($result == null) {
				return;
			} elseif($result === "repair") {
				if($item->getId() == 0) {
					$this->mainAnvilUI($player, "§cPlease hold an Item");
					return;
				}
				$this->repairUI($player);
			} elseif($result === "rename") {
				if($item->getId() == 0) {
					$this->mainAnvilUI($player, "§cPlease hold an Item");
					return;
				}
				$this->renameUI($player, "");
			} elseif($result === "lore") {
				if($item->getId() == 0) {
					$this->mainAnvilUI($player, "§cPlease hold an Item");
					return;
				}
				$this->setLoreUI($player, "");
			}
			
		});
		
		$form->setTitle($this->formTitle);
		$form->setContent("Choose: {$content}");
		$form->addButton("§l§8Repair", -1, "", "repair");
		$form->addButton("§l§8Rename", -1, "", "rename");
		$form->addButton("§l§8Set Lore", -1, "", "lore");
		$player->sendForm($form);
	}
	
	public function repairUI($player) {
		$config = $this->config->getAll();
		
		$economyAPI = EconomyAPI::getInstance();
		$myMoney = $economyAPI->myMoney($player);
		
		$getDamage = $player->getInventory()->getItemInHand()->getDamage();
		$index = $player->getInventory()->getHeldItemIndex();
        $item = $player->getInventory()->getItem($index);
		
		$price = $config["Blacksmith"]["Repair"]["Price"];
		$xpCost = $config["Blacksmith"]["Repair"]["XP-Cost"];
		
		$totalPrice =  $price * $getDamage;
		$totalXpCost = $xpCost * $getDamage;
		
		$form = $this->form->createModalForm(function(Player $player, $result) use ($config, $economyAPI, $myMoney, $item, $getDamage, $index, $totalPrice, $totalXpCost, $price, $xpCost) {
			if($result == null) {
				return;
			}
			switch($result) {
				case 0:
				$this->mainAnvilUI($player, "");
				break;
				case 1:
				if($price == false) {
					if($xpCost != false) {
						
						if($player->getXpLevel() < $totalXpCost){
							$player->sendMessage($config["Blacksmith"]["Repair"]["Message-NotEnoughXP"]);
							return;
						}
						
						$player->getInventory()->setItem($index, $item->setDamage(0));
						$player->subtractXpLevels($totalXpCost);
						$player->sendMessage($config["Blacksmith"]["Repair"]["Message-Success"]);
						
					} elseif($xpCost == false) {
						$player->getInventory()->setItem($index, $item->setDamage(0));
						$player->sendMessage($config["Blacksmith"]["Repair"]["Message-Success"]);
					}
					
				} elseif($price != false) {
					if($xpCost != false) {
						
						if($myMoney < $totalPrice){
							$player->sendMessage($config["Blacksmith"]["Repair"]["Message-NotEnoughMoney"]);
							return;
						} elseif($player->getXpLevel() < $totalXpCost) {
							$player->sendMessage($config["Blacksmith"]["Repair"]["Message-NotEnoughXP"]);
							return;
						}
						
						$player->getInventory()->setItem($index, $item->setDamage(0));
						$economyAPI->reduceMoney($player, $totalPrice);
						$player->subtractXpLevels($totalXpCost);
						$player->sendMessage($config["Blacksmith"]["Repair"]["Message-Success"]);
					} elseif($xpCost == false) {
						if($myMoney < $totalPrice){
							$player->sendMessage($config["Blacksmith"]["Repair"]["Message-NotEnoughMoney"]);
							return;
						}
						$player->getInventory()->setItem($index, $item->setDamage(0));
						$economyAPI->reduceMoney($player, $totalPrice);
						$player->sendMessage($config["Blacksmith"]["Repair"]["Message-Success"]);
					}
				}
				break;
			}
			
		});
		
		$form->setTitle($this->formTitle);
		if($price == false) {
			if($xpCost != false) {
				$form->setContent("§eDo you really want to Repair?\n\n  §7XP-Cost Per-Damage: §a{$xpCost}\n\n  §7Your Item Damage: §c{$getDamage}\n  §7Total XP-Cost: §a{$totalXpCost}\n\n");
			}elseif($xpCost == false) {
				$form->setContent("§eDo you really want to Repair?\n\n  §7Price: §aFree\n\n  §7Your Item Damage: §c{$getDamage}\n\n");
			}
		}elseif($price != false) {
			if($xpCost != false) {
				$form->setContent("§eDo you really want to Repair?\n\n  §7XP-Cost Per-Damage: §a{$xpCost}\n  §7Price Per-Damage: §a{$price} \n\n  §7Your Item Damage: §c{$getDamage}\n  §7Total XP-Cost: §a{$totalXpCost}\n  §7Total Price: §a{$totalPrice} \n\n");
			}elseif($xpCost == false) {
				$form->setContent("§eDo you really want to Repair?\n\n  §7Price Per-Damage: §a{$price} \n\n  §7Your Item Damage: §c{$getDamage}\n  §7Total Price: §a{$totalPrice} \n\n");
			}
		}
		$form->setButton1("§l§8Repair");
		$form->setButton2("§cCancel");
		$player->sendForm($form);
	}
	
	public function renameUI($player, $content) {
		$config = $this->config->getAll();
		
		$economyAPI = EconomyAPI::getInstance();
		$myMoney = $economyAPI->myMoney($player);
		
		$item = $player->getInventory()->getItemInHand();
		
		$price = $config["Blacksmith"]["Rename"]["Price"];
		$xpCost = $config["Blacksmith"]["Rename"]["XP-Cost"];
		
		$form = $this->form->createCustomForm(function(Player $player, $result) use ($config, $economyAPI, $myMoney, $item, $price, $xpCost) {
			
			if($result == null) {
				$this->mainAnvilUI($player, "");
				return;
			}
			if(!$this->alphanum($result[1])) {
				$this->renameUI($player, "§o§cDon't use any Symbol & Space!.");
				return;
			}
			if(strlen($result[1]) < 4) {
				$this->renameUI($player, "§o§cMinimum 4 Characters!.");
				return;
			}
			
			$alphabet = strlen($result[1]);
			$totalPrice = $alphabet * $price;
			$totalXpCost = $alphabet * $xpCost;
			
			if($price == false) {
				if($xpCost != false) {
					
					if($player->getXpLevel() < $totalXpCost) {
						$player->sendMessage($config["Blacksmith"]["Rename"]["Message-NotEnoughXP"]);
						return;
					}
					
					$item->setCustomName("§r§7> §f" . $result[1] . " §7<");
					$player->getInventory()->setItemInHand($item);
					$player->subtractXpLevels($totalXpCost);
					$player->sendMessage($config["Blacksmith"]["Rename"]["Message-Success"]);
					
				} elseif($xpCost == false) {
					$item->setCustomName("§r§7> §f" . $result[1] . " §7<");
					$player->getInventory()->setItemInHand($item);
					$player->sendMessage($config["Blacksmith"]["Rename"]["Message-Success"]);
				}
					
			} elseif($price != false) {
				if($xpCost != false) {
					
					if($myMoney < $totalPrice){
						$player->sendMessage($config["Blacksmith"]["Rename"]["Message-NotEnoughMoney"]);
						return;
					} elseif($player->getXpLevel() < $totalXpCost) {
						$player->sendMessage($config["Blacksmith"]["Rename"]["Message-NotEnoughXP"]);
						return;
					}
					
					$item->setCustomName("§r§7> §f" . $result[1] . " §7<");
					$player->getInventory()->setItemInHand($item);
					$economyAPI->reduceMoney($player, $totalPrice);
					$player->subtractXpLevels($totalXpCost);
				} elseif($xpCost == false) {
				if($myMoney < $totalPrice){
						$player->sendMessage($config["Blacksmith"]["Rename"]["Message-NotEnoughMoney"]);
						return;
					}
					$item->setCustomName("§r§7> §f" . $result[1] . " §7<");
					$player->getInventory()->setItemInHand($item);
					$economyAPI->reduceMoney($player, $totalPrice);
					$player->sendMessage($config["Blacksmith"]["Rename"]["Message-Success"]);
				}
			}
		});
		
		$form->setTitle($this->formTitle);
		if($price == false) {
			if($xpCost != false) {
				$form->addLabel("§eDou you really want to Rename this item?\n\n  §7Your Current Item Name:\n    §f{$item->getName()}\n\n  §7XP-Cost Per-Alphabet: §a{$xpCost}\n\n");
			}elseif($xpCost == false) {
				$form->addLabel("§eDou you really want to Rename this item?\n\n  §7Your Current Item Name:\n    §f{$item->getName()}\n\n  §7Price: §eFree\n\n");
			}
		}elseif($price != false) {
			if($xpCost != false) {
				$form->addLabel("§eDou you really want to Rename this item?\n\n  §7Your Current Item Name:\n    §f{$item->getName()}\n\n  §7Price Per-Alphabet: §a{$price} \n\n  §7XP-Cost Per-Alphabet: §a{$xpCost}\n\n");
			}elseif($xpCost == false) {
				$form->addLabel("§eDou you really want to Rename this item?\n\n  §7Your Current Item Name:\n    §f{$item->getName()}\n\n  §7Price Per-Alphabet: §a{$price} \n\n");
			}
		}
		$form->addInput("§7Rename Item: {$content}", "§7Type Alphabet...");
		$player->sendForm($form);
	}
	
	public function setLoreUI($player, $content) {
		$config = $this->config->getAll();
		
		$economyAPI = EconomyAPI::getInstance();
		$myMoney = $economyAPI->myMoney($player);
		
		$item = $player->getInventory()->getItemInHand();
		
		$price = $config["Blacksmith"]["SetLore"]["Price"];
		$xpCost = $config["Blacksmith"]["SetLore"]["XP-Cost"];
		
		$form = $this->form->createCustomForm(function(Player $player, $result) use ($config, $economyAPI, $myMoney, $item, $price, $xpCost) {
			
			if($result == null) {
				$this->mainAnvilUI($player, "");
				return;
			}
			if(!$this->alphanum($result[1])) {
				$this->setLoreUI($player, "§o§cDon't use any Symbol & Space!.");
				return;
			}
			if(strlen($result[1]) < 4) {
				$this->setLoreUI($player, "§o§cMinimum 4 Characters!.");
				return;
			}
			
			$alphabet = strlen($result[1]);
			$totalPrice = $alphabet * $price;
			$totalXpCost = $alphabet * $xpCost;
			
			if($price == false) {
				if($xpCost != false) {
					
					if($player->getXpLevel() < $totalXpCost) {
						$player->sendMessage($config["Blacksmith"]["Rename"]["Message-NotEnoughXP"]);
						return;
					}
					if(strpos($item->getName(), ">") == false && strpos($item->getName(), "<") == false) {
						$item->setCustomName("§r§7> §f" . $item->getName() . " §7<");
					}
					$item->setLore(["§r§7- §e" . $result[1]]);
					$player->getInventory()->setItemInHand($item);
					$player->subtractXpLevels($totalXpCost);
					$player->sendMessage($config["Blacksmith"]["Rename"]["Message-Success"]);
					
				} elseif($xpCost == false) {
					if(strpos($item->getName(), ">") == false && strpos($item->getName(), "<") == false) {
						$item->setCustomName("§r§7> §f" . $item->getName() . " §7<");
					}
					$item->setLore(["§r§7- §e" . $result[1]]);
					$player->getInventory()->setItemInHand($item);
					$player->sendMessage($config["Blacksmith"]["Rename"]["Message-Success"]);
				}
					
			} elseif($price != false) {
				if($xpCost != false) {
					
					if($myMoney < $totalPrice){
						$player->sendMessage($config["Blacksmith"]["Rename"]["Message-NotEnoughMoney"]);
						return;
					} elseif($player->getXpLevel() < $totalXpCost) {
						$player->sendMessage($config["Blacksmith"]["Rename"]["Message-NotEnoughXP"]);
						return;
					}
					
					if(strpos($item->getName(), ">") == false && strpos($item->getName(), "<") == false) {
						$item->setCustomName("§r§7> §f" . $item->getName() . " §7<");
					}
					$item->setLore(["§r§7- §e" . $result[1]]);
					$player->getInventory()->setItemInHand($item);
					$economyAPI->reduceMoney($player, $totalPrice);
					$player->subtractXpLevels($totalXpCost);
				} elseif($xpCost == false) {
				if($myMoney < $totalPrice){
						$player->sendMessage($config["Blacksmith"]["Rename"]["Message-NotEnoughMoney"]);
						return;
					}
					if(strpos($item->getName(), ">") == false && strpos($item->getName(), "<") == false) {
						$item->setCustomName("§r§7> §f" . $item->getName() . " §7<");
					}
					$item->setLore(["§r§7- §e" . $result[1]]);
					$player->getInventory()->setItemInHand($item);
					$economyAPI->reduceMoney($player, $totalPrice);
					$player->sendMessage($config["Blacksmith"]["Rename"]["Message-Success"]);
				}
			}
		});
		
		$form->setTitle($this->formTitle);
		if($price == false) {
			if($xpCost != false) {
				$form->addLabel("§eDou you really want to Set Lore this item?\n\n  §7XP-Cost Per-Alphabet: §a{$xpCost}\n\n");
			}elseif($xpCost == false) {
				$form->addLabel("§eDou you really want to Set Lore this item?\n\n  §7Price: §eFree\n\n");
			}
		}elseif($price != false) {
			if($xpCost != false) {
				$form->addLabel("§eDou you really want to Set Lore this item?\n\n  §7Price Per-Alphabet: §a{$price} \n\n  §7XP-Cost Per-Alphabet: §a{$xpCost}\n\n");
			}elseif($xpCost == false) {
				$form->addLabel("§eDou you really want to Set Lore this item?\n\n  §7Price Per-Alphabet: §a{$price} \n\n");
			}
		}
		$form->addInput("§7Rename Item: {$content}", "§7Type Alphabet...");
		$player->sendForm($form);
	}
	
}