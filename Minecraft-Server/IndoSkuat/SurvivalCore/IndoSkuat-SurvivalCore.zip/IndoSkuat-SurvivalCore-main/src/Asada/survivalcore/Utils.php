<?php

namespace Asada\survivalcore;

use Asada\survivalcore\SurvivalCore;

use pocketmine\utils\Config;

class Utils{
	
	private $plugin;
	
	public function __construct(SurvivalCore $plugin) {
		$this->plugin = $plugin;
	}
	
	public function getJoinQuitConfig() {
		return new Config($this->plugin->getDataFolder() . "JoinQuit.yml", Config::YAML);
	}
	
	public function getHubConfig() {
		return new Config($this->plugin->getDataFolder() . "HubConfiguration.yml", Config::YAML);
	}
	
	public function getInfoUIConfig() {
		return new Config($this->plugin->getDataFolder() . "ui/form/InfoUIConfiguration.yml", Config::YAML);
	}
	
	public function getShopUIConfig() {
		return new Config($this->plugin->getDataFolder() . "ui/form/ShopUIConfiguration.yml", Config::YAML);
	}
	
	public function getAnvilUIConfig() {
		return new Config($this->plugin->getDataFolder() . "ui/form/AnvilUIConfiguration.yml", Config::YAML);
	}
	
	public function getSellUIConfig() {
		return new Config($this->plugin->getDataFolder() . "ui/form/SellUIConfiguration.yml", Config::YAML);
	}
	
	public function getPortalsSurvivalConfig() {
		return new Config($this->plugin->getDataFolder() . "PortalsSurvival.yml", Config::YAML);
	}
	
	public function getFirsTimeJoinConfig() {
		return new Config($this->plugin->getDataFolder() . "ui/form/FirstTimeJoinConfiguration.yml", Config::YAML);
	}
}