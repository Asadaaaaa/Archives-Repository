<?php

namespace Asada\survivalcore\listener;

use Asada\survivalcore\SurvivalCore;
use Asada\survivalcore\ui\form\AnvilUI;

use pocketmine\block\Block;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;

class AnvilInteractEvent implements Listener{
	
	public $plugin;
	
	public function __construct(SurvivalCore $plugin){
		$this->plugin = $plugin;
	}
	
	public function onAnvilInteract(PlayerInteractEvent $event) {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		
		if($block->getId() === Block::ANVIL) {
			$event->setCancelled(true);
			if($event->getPlayer()->isSneaking() === false) {
				(new AnvilUI($this->plugin))->mainAnvilUI($player, "");
			}
		}
	}
	
}