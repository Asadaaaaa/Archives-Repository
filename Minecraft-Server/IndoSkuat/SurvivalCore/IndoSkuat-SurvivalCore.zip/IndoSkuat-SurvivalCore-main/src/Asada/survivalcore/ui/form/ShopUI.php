<?php

namespace Asada\survivalcore\ui\form;

// Call Main
use Asada\survivalcore\{SurvivalCore, Utils};
// Call libs Form
use Asada\survivalcore\libs\formapi\FormAPI;

// Call Frame Work
use pocketmine\item\Item;
use pocketmine\Player;

use onebone\economyapi\EconomyAPI;

class ShopUI {
	
	private $plugin;
	
	private $form;
	private $config;
	private $formTitle = "§l§8ONEBLOCK";

    public function __construct(SurvivalCore $plugin){
		$this->plugin = $plugin;
		
		$this->form = new FormAPI();
		$this->config = (new Utils($plugin))->getShopUIConfig();
    }

    /**
     * @param Player $player
     */
    public function openShopMenu(Player $player)
    {
		$config = $this->config->getAll();
        $form = $this->form->createSimpleForm(function (Player $player, $data) {
            if($data === null){
				return true;
			}
			$this->openCategoryMenu($player, $data);
        });
		$money = EconomyAPI::getInstance()->myMoney($player);
		$form->setContent("§7Your Coin: §f{$money} \n§o§7This Shop is expensive, if you wanna cheap Buy/Trade to other Players");
        $form->setTitle($this->formTitle);
        foreach ($config["shop"] as $shop) {
			$shopName = $shop["name"];
            $form->addButton($shopName, $config["shop"][$shopName]["image-type"] ? $config["shop"][$shopName]["image-type"] : -1, $config["shop"][$shopName]["image"] ? $config["shop"][$shopName]["image"] : "", $shopName);
        }
        $player->sendForm($form);
    }
	
	public function openCategoryMenu(Player $player, $category)
    {
		$config = $this->config->getAll();
        $form = $this->form->createSimpleForm(function (Player $player, $data) use ($category) {
            if($data === null){
				return true;
			}
			$this->openItemMenu($player, $category, $data, "");
        });
		$money = EconomyAPI::getInstance()->myMoney($player);
		$form->setContent("§7Your Coin: §f{$money} \n§7{$category}:");
        $form->setTitle($this->formTitle);
        foreach ($config["shop"][$category]["items"] as $item) {
			$itemName = $item["item-name"];
            $form->addButton($itemName, (isset($config["shop"][$category]["items"][$itemName]["image-type"]) ? (int)$config["shop"][$category]["items"][$itemName]["image-type"] : -1), (isset($config["shop"][$category]["items"][$itemName]["image"]) ? $config["shop"][$category]["items"][$itemName]["image"] : ""), $itemName);
        }
        $player->sendForm($form);
    }
	
	public function openItemMenu(Player $player, $category, $item, $content)
    {
        $form = $this->form->createCustomForm(function (Player $player, $data) use ($category, $item){
            if($data === null){
				return true;
			}
			if(!is_numeric($data[1])){
		        $this->openItemMenu($player, $category, $item, " §cMust be a Number");
		        return true;
		    }
			if((int)$data[1] <= 0){
				$this->openItemMenu($player, $category, $item, " §cMinimum 1");
		        return true;
			}
			$this->openConfirmation($player, $category, $item, (int)$data[1]);
        });
		$config = $this->config->getAll();
		$itemPrice = $config["shop"][$category]["items"][$item]["price"];
        $form->setTitle($this->formTitle);
        $form->addLabel("§7Item Name: §f{$item}\n§7Price Per Item: §f{$itemPrice} ");
        $form->addInput("Count:" . $content, "Type a Number");
        $player->sendForm($form);
    }
	
	public function openConfirmation(Player $player, $category, $item, int $count)
    {
        $form = $this->form->createModalForm(function (Player $player, ?bool $data) use ($category, $item, $count) {
			
			$money = EconomyAPI::getInstance()->myMoney($player);
			$config = $this->config->getAll();
			$itemPrice = $config["shop"][$category]["items"][$item]["price"];
			$itemData = $config["shop"][$category]["items"][$item];
			$cost = $itemPrice * $count;
			
			if($data === null){
				return true;
			}
			switch($data){
				case 0:
				$this->openCategoryMenu($player, $category);
				break;
				case 1:
				if($money < $cost){
					$this->openConfirmation($player, $category, $item, $count);
					break;
				}
				EconomyAPI::getInstance()->reduceMoney($player, $cost);
				$player->getInventory()->addItem(Item::get((int)$itemData["id"], isset($itemData["meta"]) ? (int)$itemData["meta"] : 0, $count));
				$this->successBought($player, $item, $count);
				break;
			}
        });
		$money = EconomyAPI::getInstance()->myMoney($player);
		$config = $this->config->getAll();
		$itemPrice = $config["shop"][$category]["items"][$item]["price"];
		$itemData = $config["shop"][$category]["items"][$item];
		$cost = $itemPrice * $count;
        $form->setTitle($this->formTitle);
		if($money < $cost){
			$form->setContent("§cYour Coin isn't enough!\n\n§7Item: §f{$item}\n§7Count: §f{$count}x\n§7Total Cost: §f{$cost} ");
			$form->setButton2("Back to Category Menu");
		}else{
			$form->setContent("§eDo you really want to buy this item?\n\n§7Item: §f{$item}\n§7Count: §f{$count}x\n§7Total Cost: §f{$cost} ");
			$form->setButton1("Confirm");
			$form->setButton2("Cancel");
		}
        $player->sendForm($form);
    }
	
	public function successBought(Player $player, $item, $count)
    {
        $form = $this->form->createModalForm(function (Player $player, ?bool $data) {
			if($data === null){
				return true;
			}
			switch($data){
				case 0:
				$this->openShopMenu($player);
				break;
				case 1:
				break;
			}
        });
        $form->setTitle($this->formTitle);
		$form->setContent("§eYou successfully bought §f{$count}x {$item}");
		$form->setButton1("§l§cClose");
		$form->setButton2("§l§8Continue Shoping");
        $player->sendForm($form);
    }
}