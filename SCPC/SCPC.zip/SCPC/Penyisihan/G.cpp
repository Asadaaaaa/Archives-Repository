#include <iostream>

using namespace std;

int main(){
    long n;

    cin >> n;

    cout << (n*2) + 1;
}