#include <bits/stdc++.h>

using namespace std;

int main(){
    int n, d, ans = 0;

    cin >> n >> d;

    int sisa = n;
    int pow[n];

    for (int i = 0; i < n; i++) {
        cin >> pow[i];
    }

    sort(pow, pow + n, greater<int>());

    for(int i = 0; pow[i]*sisa > d; i++) {
        int x = (d / pow[i]) + 1;
        sisa-=x;
        ans += 1;
    }

    cout << ans;
}