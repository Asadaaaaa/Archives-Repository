#include <iostream>

using namespace std;
// cout << ((n+1)*(n+1)) - (n*n);

int main() {

    long n, m;

    cin >> n >> m;

    if(m == 1) {

        cout << n - 1;

        return 0;
    } else if(m == 2) {

        cout << n;

        return 0;

    } else if(m >= 3) {

        cout << n * (m - 1);

        return 0;

    } else {

        cout << 0;

        return 0;
    }
    return 0;
}