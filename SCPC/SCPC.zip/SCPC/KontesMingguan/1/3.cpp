#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;
    cin >> n >> m;

    string data[n];
    int result[n] = {1, 2, 3, 4, 5};

    for (int i = 0; i < n; i++) {
        cin >> data[i];
    }

    string temp;
    int resTemp;

    for (int i = 1; i <= m; i++) {
        for (int k = 0; k < n-1; k++) {
            if (data[k][i-1] == data[k+1][i-1]) {
                continue;
            }
            for (int l = k+1; l < n; l++) {
                if (data[k][i-2] == data[l][i-2]) {
                    if (i % 2 != 0) {
                        if ((data[k][i-1] > data[l][i-1])){
                            temp = data[l];
                            resTemp = result[l];
                            for (int z = l; z > k; z--) {
                                data[z] = data[z-1];
                                result[z] = result[z-1];
                            }
                            data[k] = temp;
                            result[k] = resTemp;
                        }
                    } else {
                        if ((data[k][i-1] < data[l][i-1])){
                            temp = data[l];
                            resTemp = result[l];
                            for (int z = l; z > k; z--) {
                                data[z] = data[z-1];
                                result[z] = result[z-1];
                            }
                            data[k] = temp;
                            result[k] = resTemp;
                        }
                    }
                }       
            }
        }
    }
    for (int i = 0; i < n; i++) {
        cout << result[i] << " ";
    }
}