#include <iostream>

using namespace std;

int partition(int arr[], int start, int end)
{
 
    int pivot = arr[start];
 
    int count = 0;
    for (int i = start + 1; i <= end; i++) {
        if (arr[i] <= pivot)
            count++;
    }
 
    int pivotIndex = start + count;
    swap(arr[pivotIndex], arr[start]);
 
    int i = start, j = end;
 
    while (i < pivotIndex && j > pivotIndex) {
 
        while (arr[i] <= pivot) {
            i++;
        }
 
        while (arr[j] > pivot) {
            j--;
        }
 
        if (i < pivotIndex && j > pivotIndex) {
            swap(arr[i++], arr[j--]);
        }
    }
 
    return pivotIndex;
}

void quickSort(int arr[], int start, int end)
{
    if (start >= end) return;
    int p = partition(arr, start, end);
 
    quickSort(arr, start, p - 1);
    quickSort(arr, p + 1, end);
}

int main() {
    int n;
    int idxSplitted;

    cin >> n;

    int heightPatungSorted[n];
    int heightPatung[n];

    for(int i = 0; i < n; i++) {

        int a;

        cin >> a;

        heightPatungSorted[i] = a;
        heightPatung[i] = a;

    }

    quickSort(heightPatungSorted, 0, n - 1);

    if(n % 2 == 0) {

        idxSplitted = n / 2;

    } else if(n % 2 != 0) {

        idxSplitted  = (n + 1) / 2;

    }

    int arrAtas[idxSplitted];
    int arrBawah[n - idxSplitted];

    for(int i = 0; i < idxSplitted; i ++) {

        for(int j = 0; j < n; j++) {

            if(heightPatungSorted[i] == heightPatung[j]) {

                arrAtas[i] = heightPatung[j];

            }

        }

    }

    int curidx = 0;

    for(int j = 0; j < n; j++) {

        for(int k = idxSplitted; k < n; k++) {

            if(heightPatung[j] == heightPatungSorted[k]) {

                arrBawah[curidx] = heightPatung[j];

                curidx++;

                break;

            }

        }
    }

    string atas = "";
    string bawah = "";

    for(int i = 0; i < idxSplitted; i++) {

        string temp = "";

        if(i == 0) {

            continue;

        }
        
        if(arrAtas[i] > arrAtas[i-1]) {

            temp = "incr";

        } else {

            temp = "decr";

        }

        if(atas != "") {
            if(atas != temp) {

                cout << "Tidak";
                return 0;

            }
        }

        atas = temp;

    }

    for(int i = 0; i < idxSplitted; i++) {

        string temp = "";

        if(i == 0) {

            continue;

        }
        
        if(arrBawah[i] > arrBawah[i-1]) {

            temp = "incr";

        } else {

            temp = "decr";

        }

        if(bawah != "") {
            if(bawah != temp) {

                cout << "Tidak";
                return 0;

            }
        }

        bawah = temp;

    }

    if(atas != bawah) {

        cout << "Ya";

    } else {

        cout << "Tidak";

    }


    return 0;
}