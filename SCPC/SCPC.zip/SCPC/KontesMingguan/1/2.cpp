#include <iostream>

using namespace std;

int main() {
    
    int m, n;

    cin >> m >> n;

    int nilaiJuri[m][n];
    int nilaiMakanan[n][2];
    int nilai[m][n];

    int nilaiJago[n];

    for(int i = 0; i < m; i++) {

        cin >> nilaiJuri[i][0] >> nilaiJuri[i][1];
    }

    for(int i = 0; i < n; i++) {

        cin >> nilaiMakanan[i][0] >> nilaiMakanan[i][1];

    }

    for(int i = 0; i < m; i++) {

        for(int j = 0; j < n; j++) {

            nilai[i][j] = (nilaiJuri[i][0] * nilaiMakanan[j][0]) + (nilaiJuri[i][1] * nilaiMakanan[j][1]);
            
        }

    }

    for(int i = 0; i < n; i++) {

        nilaiJago[i] = 0;

    }

    for(int i = 0; i < m; i++) {

        int temp = 0;

        for(int j = 0; j < n; j++) {

            if(nilai[i][j] >= temp) {
                
                temp = nilai[i][j];

            }

        }

        for(int j = 0; j < n; j++) {
            
            if(nilai[i][j] == temp) {

                nilaiJago[j]++;

            }

        }

    }

    for(int i = 0; i < n; i++) {

        cout << nilaiJago[i] << endl;

    }

    return 0;
}