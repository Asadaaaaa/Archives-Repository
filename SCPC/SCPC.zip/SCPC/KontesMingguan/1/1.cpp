#include <iostream>

using namespace std;

int main() {
    int i, j;

    cin >> i >> j;

    cout << i * j;
    
    return 0;
}