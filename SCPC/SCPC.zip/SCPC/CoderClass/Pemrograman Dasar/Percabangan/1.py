a, op, b = [i for i in input().split(' ')]
a, b = int(a), int(b)

if op == '+':
    print(a + b)

elif op == '-':
    print(a - b)

elif op == '*':
    print(a * b)

elif op == '/':
    print(int(a / b))

elif op == '%':
    print(a % b)