n, k = [int(i) for i in input().split(' ')]

if n % k == 0:
    print('Hore ^_^')
else:
    print('Kecewa :(')