inp = input()

if inp == '0':
    print('nol')

try:
    int(inp)
except:
    print('kata')
else:
    if int(inp) > 0:
        print('bilangan bulat positif')

    elif int(inp) < 0:
        print('bilangan bulat negatif')