a, b, c = [int(i) for i in input().split(' ')]

if (a+b > c) and (b+c > a) and (a+c > b):
    print('segitiga')
else:
    print('bukan segitiga')