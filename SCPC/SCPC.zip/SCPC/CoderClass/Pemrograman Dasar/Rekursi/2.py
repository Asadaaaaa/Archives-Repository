n, m = [int(x) for x in input().split()]

a = b = count = 1

def move(x, y):
    global count
    if( x + 1 <= n and y + 1 <= m):
        count += 1
        move(x + 1, y)
        move(x, y + 1)

move(a, b)

print(count)