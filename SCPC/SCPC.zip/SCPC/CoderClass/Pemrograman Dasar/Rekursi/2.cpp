#include <iostream>

using namespace std;

int varCount = 1;

void move(int x, int y, int n, int m) {
    if( x + 1 <= n && y + 1 <= m) {
        varCount += 1;
        move(x+1, y, n, m);
        move(x, y+1, n, m);
    }

    return;
}

int main() {

    int n, m;

    cin >> n >> m;

    move(1, 1, n, m);
    cout << varCount;
    
    return 0;
}