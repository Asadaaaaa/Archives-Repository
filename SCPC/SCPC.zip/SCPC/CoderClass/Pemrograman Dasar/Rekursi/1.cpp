#include <iostream>
#include <cmath>

using namespace std;

float t(float n) {
    if(n > 1) {
        return 1 + t(ceil(n/2)) + t(floor(n/2));
    } else {
        return 1;
    }
}

int main() {
    float n;

    cin >> n;

    cout << t(n);

    return 0;
}