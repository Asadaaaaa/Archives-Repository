inp = input()

inpArr = inp.split(' ')
total = 0
x = int(inpArr[3])

while(True):
    if(x == int(inpArr[3]) and total != 0): 
        break
    x = (int(inpArr[0]) * x + int(inpArr[1])) % int(inpArr[2])
    total += 1

print(total)