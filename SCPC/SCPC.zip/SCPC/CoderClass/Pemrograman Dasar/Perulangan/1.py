inp = input()

inpArr = inp.split(' ')

a = int(inpArr[0])
b = int(inpArr[1])
x = int(inpArr[2])
y = int(inpArr[3])

while(x < y):
    print(x)
    x = a * x + b
