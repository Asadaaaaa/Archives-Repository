n = int(input())

total = 0

for i in range(n):
    inp = input().split(' ')
    total += int(inp[i])

print(total)