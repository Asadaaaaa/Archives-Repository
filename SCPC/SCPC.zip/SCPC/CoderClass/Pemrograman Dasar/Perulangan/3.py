inp = input()

inpArr = inp.split(' ')

n = int(inpArr[0])
m = int(inpArr[1])
l = int(inpArr[2])

up = 0

for i in range(n):
    if((i + 1) > l):
        if(n - (i + 1) < l):
            for j in range(m):
                print('*', end='')
        else:
            for j in range(m):
                if((j + 1) <= l):
                    print('*', end='')
                else:
                    print('.', end='')
    else:
        for j in range(m):
            print('*', end='')
    print()