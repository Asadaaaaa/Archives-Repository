n, m, l = [int(i) for i in input().split(' ')]


for i in range(l):
    for i in range(m):
        print('*', end='')
    print()

for i in range(n - (l*2)):
    for i in range(l):
        print('*', end='')

    for j in range(m-l):
        print('.', end='')

    print()

for i in range(l):
    for i in range(m):
        print('*', end='')
    print()