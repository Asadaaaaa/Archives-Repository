total = input()

strength = input().split(' ')

stronger = 0

for i in range(int(total)):
    if(int(strength[i]) > stronger):
        stronger = int(strength[i])

print(stronger)