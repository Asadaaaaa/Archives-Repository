#include <iostream>

using namespace std;

int main(){
    int n; cin >> n;

    int num[n];

    for(int i = 0; i < n; i++){
        cin >> num[i];
    }

    for(int i = 0; i < n; i++){
        cout << num[i];
        if(n % 2 != 0){
            if(i != n-1-i){
                cout << " " << num[n-1-i] << " ";
            }
            else {
                break;
            }
        }
        else{
            if(i+1 != n-1-i){
                cout << " " << num[n-1-i] << " ";
            }
            else {
                cout << " " << num[n-1-i];
                break;
            }
        }
    }
}