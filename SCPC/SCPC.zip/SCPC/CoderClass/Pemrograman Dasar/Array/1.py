n, k = [int(i) for i in input().split()]

found = {i for i in input().split()}
numbers = {str(i) for i in range(1, n+1)}

for i in found:
    numbers.discard(i)

print(' '.join([str(i) for i in sorted([int(i) for i in numbers])]))