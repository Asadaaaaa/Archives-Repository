n = int(input())

l = list()

for i in range(n):
    temp = int(input())
    l.append(str(temp))

for i in reversed(l):
    print(i)