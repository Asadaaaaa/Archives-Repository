n, q = [int(i) for i in input().split()]
text = input()

op = list()

for i in range(q): op.append([int(i) for i in input().split()])

for i in op:
    if i[0] == 1:
        textL = list(text)
        textL[i[1]-1], textL[i[2]-1] = textL[i[2]-1], textL[i[1]-1]
        text = ''.join(textL)
    
    else:
        text = text[:(i[1]-1)] + text[(i[1]-1):(i[2])][::-1] + text[(i[2]):]

print(text)