#include <iostream>
#include <bits/stdc++.h>

using namespace std;

string swapChar(string text, int a, int b) {
    char char1;

    char1 = text[a-1];
    text[a-1] = text[b-1];
    text[b-1] = char1;

    return text;
}

int main() {

    int len, op;
    string text;

    cin >> len >> op;
    cin >> text;

    int operation[op][3];

    for(int i = 0; i < op; i++) {

        cin >> operation[i][0] >> operation[i][1] >> operation[i][2];

    }
    
    for(int i = 0; i < op; i++) {

        if(operation[i][0] == 1) {
            
            text = swapChar(text, operation[i][1], operation[i][2]);

        } else if(operation[i][0] == 2) {

            reverse(text.begin() + operation[i][1] - 1, text.begin() + operation[i][2]);

        }

    }

    cout << text;


    return 0;
}