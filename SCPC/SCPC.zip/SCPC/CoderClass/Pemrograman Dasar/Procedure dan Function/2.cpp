#include <iostream>

using namespace std;

int main() {

    int n;

    cin >> n;

    int barang[n];

    for(int i = 0; i < n; i++) {

        cin >> barang[i];

    }

    for(int i = 0; i < n; i++) {

        for(int j = i + 1; j < n; j++) {
            
            if(barang[i] > barang[j]) {

                swap(barang[i], barang[j]);

                cout << i + 1 << " " << j + 1 << endl;
                
            }
        }

    }

    return 0;
}