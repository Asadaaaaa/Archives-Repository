#include <iostream>

using namespace std;

int g(int n) {
    int facCount = 0;

    for(int i = 1; i <= n; i++) {

        if(n % i == 0) {

            facCount++;

        }
        
    }

    return facCount;
}

int h(int n) {
    int total = 0;

    for(int i = 1; i <= n; i++) {
        
        total += g(i);

    }

    return total;
}

int main() {
    int n;

    cin >> n;
    cout << h(n);

    
    return 0;
}