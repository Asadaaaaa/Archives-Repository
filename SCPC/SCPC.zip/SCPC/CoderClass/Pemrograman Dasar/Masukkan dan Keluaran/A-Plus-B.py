input = input()

inputSplit = input.split(' ')

print(int(inputSplit[0]) + int(inputSplit[1]))