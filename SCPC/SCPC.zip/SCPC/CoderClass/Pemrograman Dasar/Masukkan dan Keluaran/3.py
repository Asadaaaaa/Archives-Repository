inp = input()

inpSpl = inp.split(' ')

print(float(int(inpSpl[0]) + int(inpSpl[1]) + int(inpSpl[2]) + int(inpSpl[3]) + int(inpSpl[4]) + int(inpSpl[5])) / 6)