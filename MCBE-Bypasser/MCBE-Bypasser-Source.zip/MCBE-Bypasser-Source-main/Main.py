import Algos
import time

def mainPage(content):
    Algos.menuUI(content, ["Start Trial Bypasser", "Fix System", "Info Author", "Exit"])
    
    inptResult = input("Choose Menu: ")
    if(inptResult == "1"):
        runBypass()
        return
    elif(inptResult == "2"):
        fixSystem()
        return
    elif(inptResult == "3"):
        Algos.os.system("start \"\" https://github.com/Asadaaaaa")
        mainPage("")
        return
    elif(inptResult == "4"):
        return
    else:
        Algos.notificator("Menu not found", 2, 38, 50)
        mainPage("")
        return

    return

def runBypass():
    Algos.menuUI("", [])
    print("> When pop up showed up, please click 'Yes'")
    time.sleep(3)
    Algos.os.system("powershell -command \"dependencies\\1.reg\"")
    time.sleep(1)
    print("> Waiting...")
    time.sleep(5)
    print("> Stopping Microsoft Services...")
    Algos.os.system("powershell -command \"dependencies\\stop.bat\"")
    time.sleep(3)
    Algos.os.system("dependencies\\app.lnk")
    time.sleep(5)
    Algos.os.system("taskkill /IM RuntimeBroker.exe /F")
    mainPage("Some System has been changed, you must 'Fix System' after playing!")
    return

def fixSystem():
    Algos.menuUI("", [])
    print("> When pop up showed up, please click 'Yes'")
    time.sleep(3)
    Algos.os.system("powershell -command \"dependencies\\1.reg\"")
    time.sleep(1)
    print("> Waiting...")
    time.sleep(5)
    print("> Stopping Microsoft Services...")
    Algos.os.system("powershell -command \"dependencies\\start.bat\"")
    mainPage("Maybe some system has been fixed")

mainPage("")