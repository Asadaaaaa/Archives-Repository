# PHP-Obfuscator
Script for Obfuscating/Encrypting PHP Code
